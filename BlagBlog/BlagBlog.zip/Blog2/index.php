<?php
session_start();

require_once('utils/autoload.php');
require_once('utils/init.php');
require_once('utils/router.php');