<style>
    @import url('https://fonts.googleapis.com/css2?family=Montserrat+Alternates&display=swap');
    footer {
        
        background: #19245c;
        padding: 5px;
        display : table-row;
	height: 100px;
   
    
    }
p {
    display:flex;
    align-items: center;
    height: 100px;
    justify-content: center;
    font-family: 'Montserrat Alternates', sans-serif;
    
    
}
    footer a {
        color: whitesmoke;
        text-decoration: none;
        text-transform:uppercase;
        font-family: 'Montserrat Alternates', sans-serif;
        

    }

    footer a:hover {
        color: white;
    }
</style>
<footer>
    <p>
    <a href="/Blog2">Revenir à la page d'accueil</a>
    </p>
</footer>
</body>

</html>